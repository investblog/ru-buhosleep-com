Buho 1.0 — simple keep-awake for Windows (portable edition)
===========================================================

One owl in the tray, five modes, zero setup. Keep the screen on, keep the PC
awake, switch to the Power Saver or High Performance plan, set an awake timer
(30 minutes to 8 hours, or until end of day) — and it all switches off by
itself. Speaks 12 languages, follows your Windows display language.

Run buho.exe. That's it.

Portable
--------
This folder is self-contained. Settings live in buho.ini next to buho.exe
(the empty stub shipped here is what switches Buho into portable mode — keep
it). Nothing is written to the registry or to your user profile, there are no
temp files, no network access, no telemetry. Power-plan changes are system
state: Buho restores your previous plan when it exits and, should it ever be
killed, on its next start. Moving the folder to another drive or PC keeps
your settings.

Hotkeys (global)
----------------
  Pause  or  Alt+`        cycle Off -> Screen -> Awake -> Power Saver ->
                          High Performance -> Off (a tray notification names
                          the new mode; ` is the key left of 1)
  Ctrl+Shift+Alt+S        Keep Screen On       (press again to switch off)
  Ctrl+Shift+Alt+A        Keep PC Awake
  Ctrl+Shift+Alt+P        Power Saver
  Ctrl+Shift+Alt+H        High Performance

Change or disable them in buho.ini, e.g.

  [buho]
  Hotkey.Cycle=ScrollLock
  Hotkey.Cycle2=
  Hotkey.HighPerf=
  language=de            (en ru de fr es it pt-br ja ko zh-cn pl tr)

Notes
-----
* Windows Home editions may lack the High Performance plan; Buho says so and
  stays Off instead of guessing.
* Only one Buho runs at a time (the Microsoft Store edition counts).
* This is the 32-bit build. On 64-bit Windows prefer buho-1.0-win64.zip.

Free forever. The big brother with triggers, statistics and Drive Alive is
BuhoSleep — https://buhosleep.com

Copyright (c) 2026 301. Freeware; see license.txt.
